package timezone;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author RAMESHA
 */
public class TimeZoneCalculator extends javax.swing.JFrame {

    private static Date date,time;
    private static String hour, min, sec;
    private static Calendar calendar;
    private SimpleDateFormat sdf;

    public TimeZoneCalculator() {
        initComponents();
        sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        addTimeZones();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jLabel2 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabelUTC = new javax.swing.JLabel();
        jLabelPST = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jComboBoxTimeZone = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jLabelRequiredTimeZone = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("UTC and PST time Calculator");

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("Date");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 60, -1, 20));

        jDateChooser1.setToolTipText("Choose the year, month and date");
        jPanel1.add(jDateChooser1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 60, 185, -1));

        jLabel2.setText("Time");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 110, -1, -1));

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23" }));
        jComboBox1.setToolTipText("Hours");
        jPanel1.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 110, -1, -1));

        jLabel3.setText(":");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 110, -1, -1));

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59" }));
        jComboBox2.setToolTipText("Minutes");
        jPanel1.add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 110, -1, -1));

        jLabel4.setText(":");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 110, -1, -1));

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59" }));
        jComboBox3.setToolTipText("Seconds");
        jPanel1.add(jComboBox3, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 110, -1, -1));

        jButton1.setText("CONVERT");
        jButton1.setToolTipText("Select a date and a time and press to Calculate the UTC and PST time");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 190, 320, -1));

        jLabel5.setText("UTC Time :");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 80, -1, -1));

        jLabelUTC.setToolTipText("UTC Time");
        jLabelUTC.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(jLabelUTC, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 80, 143, 20));

        jLabelPST.setToolTipText("PST Time");
        jLabelPST.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jPanel1.add(jLabelPST, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 110, 143, 20));

        jLabel8.setText("PST Time :");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 110, -1, -1));

        jLabel6.setText("Time Zone : ");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, -1, -1));

        jLabel7.setBorder(javax.swing.BorderFactory.createTitledBorder("Sri Lankan Time"));
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 340, 139));

        jComboBoxTimeZone.setToolTipText("Select a time zone");
        jComboBoxTimeZone.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jComboBoxTimeZoneMouseReleased(evt);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jComboBoxTimeZoneMouseClicked(evt);
            }
        });
        jComboBoxTimeZone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxTimeZoneActionPerformed(evt);
            }
        });
        jComboBoxTimeZone.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jComboBoxTimeZonePropertyChange(evt);
            }
        });
        jPanel1.add(jComboBoxTimeZone, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 290, 230, -1));

        jLabel9.setBorder(javax.swing.BorderFactory.createTitledBorder("UTC and PST Time"));
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 40, 330, 140));

        jLabelRequiredTimeZone.setText("Required Time Zone : ");
        jPanel1.add(jLabelRequiredTimeZone, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 290, 230, -1));

        jLabel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 280, 130, 30));

        jLabel10.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "UTC and PST", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 740, 220));

        jLabel12.setBorder(javax.swing.BorderFactory.createTitledBorder("Additional Time Zones"));
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, 740, 120));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 758, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 395, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked

        date = jDateChooser1.getDate();

        hour = jComboBox1.getSelectedItem().toString();
        min = jComboBox2.getSelectedItem().toString();
        sec = jComboBox3.getSelectedItem().toString();

        time = addTimeToDate();

        sdf.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
        jLabelUTC.setText(sdf.format(time));

        sdf.setTimeZone(java.util.TimeZone.getTimeZone("PST"));
        jLabelPST.setText(sdf.format(time));

    }//GEN-LAST:event_jButton1MouseClicked

    private void jComboBoxTimeZonePropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jComboBoxTimeZonePropertyChange

    }//GEN-LAST:event_jComboBoxTimeZonePropertyChange

    private void jComboBoxTimeZoneMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBoxTimeZoneMouseReleased

    }//GEN-LAST:event_jComboBoxTimeZoneMouseReleased

    private void jComboBoxTimeZoneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBoxTimeZoneMouseClicked

    }//GEN-LAST:event_jComboBoxTimeZoneMouseClicked

    private void jComboBoxTimeZoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxTimeZoneActionPerformed
        try {
            jLabelRequiredTimeZone.setText(jComboBoxTimeZone.getSelectedItem().toString());
            calculateTime(jComboBoxTimeZone.getSelectedItem().toString());
        } catch (NullPointerException e) {
            System.out.println("Null");
        }
    }//GEN-LAST:event_jComboBoxTimeZoneActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TimeZoneCalculator().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBoxTimeZone;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabelPST;
    private javax.swing.JLabel jLabelRequiredTimeZone;
    private javax.swing.JLabel jLabelUTC;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables

    private void addTimeZones() {

        String[] availableIDs = TimeZone.getAvailableIDs();

        DefaultComboBoxModel<String> defaultComboBoxModel = new DefaultComboBoxModel<String>(availableIDs);
        jComboBoxTimeZone.setModel(defaultComboBoxModel);
    }

    private Date addTimeToDate() {
        calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.HOUR_OF_DAY, Integer.parseInt(hour));
        calendar.add(Calendar.MINUTE, Integer.parseInt(min));
        calendar.add(Calendar.SECOND, Integer.parseInt(sec));
        Date time = calendar.getTime();

        return time;
    }

    private void calculateTime(String toString) {
        sdf.setTimeZone(java.util.TimeZone.getTimeZone(toString));
        jLabel11.setText(sdf.format(time));
    }
}
